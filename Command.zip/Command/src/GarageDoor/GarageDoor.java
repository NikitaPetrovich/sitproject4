package GarageDoor;

public class GarageDoor {
    String name;
    public GarageDoor( String name){
        this.name = name;
    }
    void up(){
        System.out.println(name + " is Open");
    }
    void down(){
        System.out.println(name + " is Close");
    }
}
