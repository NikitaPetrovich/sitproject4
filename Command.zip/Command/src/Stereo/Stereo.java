package Stereo;

public class Stereo {
    String name;
    public Stereo(String name){
        this.name = name;
    }
    void on(){
        System.out.println(name + " stereo is On");
    }
    void off(){
        System.out.println(name + " stereo is Off");
    }
    void setCD(){
        System.out.println(name + " stereo is set for CD input");
    }
    void setDVD(){
        System.out.println(name + " stereo is set for DVD input");
    }
    void setRadio(){
        System.out.println(name + " stereo is set for Radio input");
    }
    void setVolume( int i){
        System.out.println(name + " stereo volume set to " + i);
    }
}
