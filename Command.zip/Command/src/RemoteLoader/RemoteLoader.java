package RemoteLoader;


import MacroCommand.MacroCommand;
import NoCommand.NoCommand;
import Interface.Command;
import GarageDoor.*;
import RemoteControl.RemoteControl;
import Light.*;
import Stereo.*;
import TV.*;

public class RemoteLoader {
    public static void main(String[] args) {
        //ВЫПОЛНЕНИЯ С КНОПКОЙ ОТМЕНА
        RemoteControl remoteControl = new RemoteControl();
        
        Light livinRoomLight = new Light("Living Room");
        TV tv = new TV("Living Room");
        GarageDoor garageDoor = new GarageDoor("Garage Door");
        Stereo stereo = new Stereo("Living Room");
       
        LightOnCommand livinRoomLightOn = new LightOnCommand(livinRoomLight);
        LightOffCommand livinRoomLightOff = new LightOffCommand(livinRoomLight);
        TVOnCommand tvOn = new TVOnCommand(tv);
        TVOffCommand tvOff = new TVOffCommand(tv);
        GarageDoorUpCommand garageDoorUpCommand = new GarageDoorUpCommand(garageDoor);
        GarageDoorDownCommand garageDoorDownCommand = new GarageDoorDownCommand(garageDoor);
        StereoOnCommand stereoOnCommand = new StereoOnCommand(stereo);
        StereoOffCommand stereoOffCommand = new StereoOffCommand(stereo);
        
        remoteControl.setCommand(0, livinRoomLightOn, livinRoomLightOff);
        remoteControl.setCommand(1, tvOn, tvOff);
        remoteControl.setCommand(2, stereoOnCommand, stereoOffCommand);
        remoteControl.setCommand(3, garageDoorUpCommand, garageDoorDownCommand);
        
        remoteControl.onButtonWasPushed(0);
        remoteControl.offButtonWasPushed(0);
        remoteControl.onButtonWasPushed(1);
        remoteControl.offButtonWasPushed(1);
        remoteControl.onButtonWasPushed(2);
        remoteControl.offButtonWasPushed(2);
        remoteControl.onButtonWasPushed(3);
        remoteControl.offButtonWasPushed(3);
        System.out.println(remoteControl);
        remoteControl.undoButtonWasPushed();
        remoteControl.offButtonWasPushed(0);
        remoteControl.onButtonWasPushed(0);
        System.out.println(remoteControl);
        remoteControl.undoButtonWasPushed();
        
        //РЕАЛИЗАЦИЯ С ПОМОЩЬЮ МАКРОСА
        Command[] partyOn = { livinRoomLightOn, stereoOnCommand, tvOn, garageDoorUpCommand};
        Command[] partyOff = { livinRoomLightOff, stereoOffCommand, tvOff, garageDoorDownCommand};
        
        MacroCommand partyOnMacro = new MacroCommand(partyOn);
        MacroCommand partyOffMacro = new MacroCommand(partyOff);
        
        remoteControl.setCommand(0, partyOnMacro, partyOffMacro);
        
        System.out.println(remoteControl);
        System.out.println("---Pushing Macro On---");
        remoteControl.onButtonWasPushed(0);
        System.out.println("---Pushing Macro Off---");
        remoteControl.offButtonWasPushed(0);
    }
}
