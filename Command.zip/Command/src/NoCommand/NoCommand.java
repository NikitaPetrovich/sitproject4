package NoCommand;

import Interface.Command;

public class NoCommand implements Command {
    public void execute(){};
    public void undo(){}
}
