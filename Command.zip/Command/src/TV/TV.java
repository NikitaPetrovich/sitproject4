package TV;

public class TV {
    String name;
    public TV(String name){
        this.name = name;
    }
    void on(){
        System.out.println(name + " TV is On" );
    }
    void off(){
        System.out.println(name + " TV is Off" );
    }
    void setInputChannel( int i ){
        System.out.println(name + " TV channel set to " + i);
    }
    void setVolume( int i){
        System.out.println(name + " TV volume set to " + i);
    }
}
