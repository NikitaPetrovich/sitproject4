package Light;

public class Light {
    String name;
    public Light( String name){
        this.name = name;
    }
    void on(){
        System.out.println(name + " light is On");
    }
    void off(){
        System.out.println(name + " light is Off");
    }
}
