package command;


public interface CommandInterface {
    public void execute();
}
