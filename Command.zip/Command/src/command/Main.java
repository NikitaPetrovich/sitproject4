
package command;


public class Main {

    public static void main(String[] args) {
        SimpleRemoteControl remote = new SimpleRemoteControl();
        Light light = new Light();
        GradeDoor  gradeDoor = new  GradeDoor();
        LightOnCommand lightOn = new LightOnCommand(light);
        GradeDoorOpenCommand gradeOpen = new  GradeDoorOpenCommand(gradeDoor);
        remote.setCommand(lightOn);
        remote.buttonWasPressed();
        remote.setCommand(gradeOpen);
        remote.buttonWasPressed();
    }

}
