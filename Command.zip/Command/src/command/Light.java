

package command;

public class Light {

    void on() { System.out.println("Свет включен");}
       
}
