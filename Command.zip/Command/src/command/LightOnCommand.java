/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package command;
/**
 *
 * @author stud221
 */
public class LightOnCommand implements CommandInterface {
    Light light;

    public LightOnCommand(Light light) {
    this.light = light;
    }


    public void execute() {
       light.on();
    }

}
