

package command;

public class GradeDoor {

    void up() {System.out.println("Grade Door is Open");}
    /*void down() {System.out.println("");}
    void stop() {System.out.println("stop()");}
    void lihgtOn() {System.out.println("lightOn()");}
    void lightOff () {System.out.println("lightOff()");}*/
}
