
package command;

public class GradeDoorOpenCommand implements CommandInterface {

    GradeDoor gradeDoor;

    public GradeDoorOpenCommand(GradeDoor gradeDoor) {
        this.gradeDoor = gradeDoor;
    }

    public void execute() {
        gradeDoor.up();
       /* gradeDoor.down();
        gradeDoor.stop();
        gradeDoor.lihgtOn();
        gradeDoor.lightOff();*/
    }

}
